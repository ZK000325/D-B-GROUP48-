#Yolov8 Minimum Training Example



This is the most basic 'yolov8' training example. Run 'Python train. py' to start the training, and then view the training results in the 'runs' directory



`The datasets/demo 'contains an example dataset that needs to be replaced with its own labeled data for' train/images' and 'train/labels'. At the same time, some data needs to be placed in the' valid/images' and 'valid/labels' for validation (this is the basis for selecting the optimal model during the training process)



For more complex training, please refer to the official document of Ultratics（ https://docs.ultralytics.com/modes/train/ ）
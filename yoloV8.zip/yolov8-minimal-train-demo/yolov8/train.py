from ultralytics import YOLO

model = YOLO('yolov8l.pt')

model.train(
  data = 'C:/Users/123/PycharmProjects/yoloV8/yolov8-minimal-train-demo/yolov8/datasets/demo/data.yaml',
  epochs = 300,
  imgsz = 640,
  workers = 0,
  batch = 6
)

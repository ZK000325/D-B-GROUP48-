#This is the module to predict a picture or pictures in folder

the file yolo.py is used to predict the picture,

and the result of prediction will be saved in the folder named "runs".

if you want to train the model ,open the folder named "yolov8-minimal-train-demo"



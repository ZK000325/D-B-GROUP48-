# This is the GUI part pf IoT 
If you want to run the code ,open the src folder
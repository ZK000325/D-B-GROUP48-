import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;



import javax.swing.*;
public class Bigframe extends JFrame implements ActionListener {
 JButton nextp;
 
 JLabel title;
 String path="C:\\Users\\123\\PycharmProjects\\yoloV8\\yolov8-minimal-train-demo\\yolov8\\runs\\detect\\train4";
 File dir;
 String[] fileList;
 ImageIcon p1;
 JLabel pp1;
  static int aa=0;
 
 
 Bigframe(){
	 this.nextp=new JButton("next page");
	 this.setLayout(new BorderLayout());
	 this.title=new JLabel("Result Of YOLO Test Sets",JLabel.CENTER);
	 Container content=this.getContentPane();
	 content.add(BorderLayout.NORTH,title);
	 
	 
	 this.dir=new File(path);
	 this.fileList=dir.list();
	 
	 p1=new ImageIcon(path+"\\"+fileList[aa]);
	 
	 pp1=new JLabel(p1);

	
	 content.add(BorderLayout.CENTER,pp1);
	 
	 
	 
	 
	 nextp.addActionListener(this);
	 this.setSize(1000,2000);this.setVisible(true);
 }
 public void actionPerformed(ActionEvent e) {
	 if(aa<fileList.length)this.aa++;
	 this.getContentPane().remove(pp1);
	 this.p1=new ImageIcon(path+"\\"+fileList[aa]);
	 
	 this.pp1=new JLabel(p1);
	
     this.getContentPane().remove(pp1);
    
	 this.getContentPane().add(BorderLayout.CENTER,this.pp1); 
	
	 
	 this.setVisible(true);
	
		}
 

}

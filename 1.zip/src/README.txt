#This part is the GUI of the IoT,shows the performance of the model 

if you want to run the GUI on your own computer 

change the String "path" in the Bigframe.java to the folder train12 ,which is in the yoloV8 folder.
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;



import javax.swing.*;
public class gui extends JFrame implements ActionListener {
JButton prevp;
Bigframe big;
gui()
{
	this.setLayout(new FlowLayout());
	prevp=new JButton("previous page");
	big=new Bigframe();
	Container content=this.getContentPane();
	content.add(this.prevp);
	content.add(this.big.nextp);
	this.big.getContentPane().add(BorderLayout.SOUTH,	this.getContentPane());
	prevp.addActionListener(this);
	
	
}
public void actionPerformed(ActionEvent e) {
	 if(this.big.aa>0)this.big.aa--;
	 this.big.getContentPane().remove(this.big.pp1);
	 this.big.p1=new ImageIcon(this.big.path+"\\"+this.big.fileList[this.big.aa]);
	 this.big.pp1=new JLabel(this.big.p1);
	
    this.big.getContentPane().remove(this.big.pp1);
	 this.big.getContentPane().add(BorderLayout.CENTER,this.big.pp1); 
	
	 
	 this.big.setVisible(true);
	
		}
public static void main(String args[]) 
	{
		gui a=new gui();
	}
}

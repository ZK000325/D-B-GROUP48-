/*
 Navicat Premium Data Transfer

 Source Server         : root
 Source Server Type    : MySQL
 Source Server Version : 80015
 Source Host           : localhost:3306
 Source Schema         : robot

 Target Server Type    : MySQL
 Target Server Version : 80015
 File Encoding         : 65001

 Date: 27/06/2023 02:49:39
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for explorationrecords
-- ----------------------------
DROP TABLE IF EXISTS `explorationrecords`;
CREATE TABLE `explorationrecords`  (
  `RecordID` int(11) NOT NULL AUTO_INCREMENT,
  `RobotID` int(11) NULL DEFAULT NULL,
  `MazeID` int(11) NULL DEFAULT NULL,
  `StartTime` timestamp(0) NULL DEFAULT NULL,
  `EndTime` timestamp(0) NULL DEFAULT NULL,
  `TotalTime` time(0) NULL DEFAULT NULL,
  `Status` enum('成功','失败') CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `TreasureImage` blob NULL,
  `TreasureType` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`RecordID`) USING BTREE,
  INDEX `RobotID`(`RobotID`) USING BTREE,
  INDEX `MazeID`(`MazeID`) USING BTREE,
  CONSTRAINT `explorationrecords_ibfk_1` FOREIGN KEY (`RobotID`) REFERENCES `robots` (`RobotID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `explorationrecords_ibfk_2` FOREIGN KEY (`MazeID`) REFERENCES `mazes` (`MazeID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mazes
-- ----------------------------
DROP TABLE IF EXISTS `mazes`;
CREATE TABLE `mazes`  (
  `MazeID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Image` blob NULL,
  `Description` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`MazeID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for realtimeimages
-- ----------------------------
DROP TABLE IF EXISTS `realtimeimages`;
CREATE TABLE `realtimeimages`  (
  `ImageID` int(11) NOT NULL AUTO_INCREMENT,
  `RobotID` int(11) NULL DEFAULT NULL,
  `Image` blob NULL,
  `CaptureTime` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ImageID`) USING BTREE,
  INDEX `RobotID`(`RobotID`) USING BTREE,
  CONSTRAINT `realtimeimages_ibfk_1` FOREIGN KEY (`RobotID`) REFERENCES `robots` (`RobotID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for realtimemaps
-- ----------------------------
DROP TABLE IF EXISTS `realtimemaps`;
CREATE TABLE `realtimemaps`  (
  `MapID` int(11) NOT NULL AUTO_INCREMENT,
  `RobotID` int(11) NULL DEFAULT NULL,
  `MazeID` int(11) NULL DEFAULT NULL,
  `Image` blob NULL,
  `CaptureTime` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`MapID`) USING BTREE,
  INDEX `RobotID`(`RobotID`) USING BTREE,
  INDEX `MazeID`(`MazeID`) USING BTREE,
  CONSTRAINT `realtimemaps_ibfk_1` FOREIGN KEY (`RobotID`) REFERENCES `robots` (`RobotID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `realtimemaps_ibfk_2` FOREIGN KEY (`MazeID`) REFERENCES `mazes` (`MazeID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for robots
-- ----------------------------
DROP TABLE IF EXISTS `robots`;
CREATE TABLE `robots`  (
  `RobotID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) NULL DEFAULT NULL,
  `Name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Image` blob NULL,
  `Status` enum('活跃','不活跃','维护中') CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `LastActiveTime` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`RobotID`) USING BTREE,
  INDEX `UserID`(`UserID`) USING BTREE,
  CONSTRAINT `robots_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Password` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Email` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`UserID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;

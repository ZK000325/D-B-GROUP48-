package com.robot.Config;

import com.mchange.v2.c3p0.ComboPooledDataSource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class dbConfig {
    ComboPooledDataSource sourceData =  new ComboPooledDataSource();

    public  Connection getConnection(){
        Connection connection =null;
        try {
             connection = sourceData.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return  connection;
    }

    //释放资源
    public static void getCloseConnect(ResultSet res, PreparedStatement pres, Connection conn) {
        if(res !=null){
            try {
                res.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (pres != null){
            try {
                pres.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if(conn != null){
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

//    public static void main(String[] args) throws SQLException {
//        dbConfig DBload =new dbConfig();
//        Connection db = DBload.getConnection();
//        String sql =  "select * from users";
//        PreparedStatement preparedStatement = db.prepareStatement(sql);
////        ResultSet resultSet = preparedStatement.executeQuery();
//    }
}

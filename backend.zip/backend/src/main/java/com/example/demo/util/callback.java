package com.example.demo.util;

public interface callback {

    public void run();

}

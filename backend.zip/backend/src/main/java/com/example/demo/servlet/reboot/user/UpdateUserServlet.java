package com.example.demo.servlet.reboot.user;

import com.example.demo.dao.reboot.UserDao;
import com.example.demo.domian.User;
import com.example.demo.util.Message;
import com.example.demo.util.callback;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/updateUser")
public class UpdateUserServlet extends HttpServlet {
    private UserDao userDao =new UserDao();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int userId = Integer.parseInt(request.getParameter("userId"));
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");

        // 创建User对象并设置相应的属性值
        User updatedUser = new User(userId, username, password, email);

        // 调用相应的DAO方法更新数据库中的用户信息
        boolean success = userDao.updateUser(updatedUser);

        if (success) {
            // 更新成功，重定向到用户列表页面
            new Message("添加成功", response, new callback() {
                @Override
                public void run() {
                    try {
                        response.sendRedirect("/reboot/user/user.jsp");
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }

                }
            });
        } else {
            // 更新失败，返回错误消息
            response.sendRedirect("users.jsp?error=1");
        }
    }
}

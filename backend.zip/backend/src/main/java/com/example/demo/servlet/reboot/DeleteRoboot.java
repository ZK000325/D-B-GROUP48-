package com.example.demo.servlet.reboot;

import com.example.demo.dao.reboot.RobotDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/delete")
public class DeleteRoboot extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int robotId = Integer.parseInt(req.getParameter("robotId"));
        Boolean status = RobotDao.deleteRobot(robotId);
        PrintWriter writer = resp.getWriter();

        if (status){
            writer.write("<script>alert('添加成功')</script>");
            resp.sendRedirect("reboot/index.jsp?status=0");
        }else {
            writer.write("<script>alert('添加成功')</script>");
            resp.sendRedirect("reboot/index.jsp?status=1");
        }
    }
}

package com.example.demo;

import com.mysql.cj.xdevapi.Session;
import com.robot.Config.dbConfig;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private Connection connection = new dbConfig().getConnection();
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String username = req.getParameter("username");
        String password = req.getParameter("password");
        // 执行查询
        String sql = "SELECT * FROM users WHERE Username = ? AND Password = ?";

        try {
            PreparedStatement statement = connection.prepareStatement(sql);

            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                // 登录成功，可以进行相应的操作，如跳转到欢迎页面
                HttpSession session = req.getSession();
                System.out.println("成功");
                session.setAttribute("userId",resultSet.getInt(1));
                resp.sendRedirect("index.jsp?status=success");

            } else {
                // 登录失败，重定向回登录页面，并显示错误消息
                resp.sendRedirect("index.jsp?status=fall");

            }


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
//        super.doPost(req, resp);
    }
}

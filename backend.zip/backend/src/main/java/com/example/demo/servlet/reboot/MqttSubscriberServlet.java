package com.example.demo.servlet.reboot;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.eclipse.paho.client.mqttv3.IMqttMessageListener;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

//这段代码是一个用于订阅 MQTT 消息和 TCP 消息的 Servlet。
@WebServlet(value = "/MqttSubscriber", loadOnStartup = 1)
public class MqttSubscriberServlet extends HttpServlet {

    private MqttClient mqttClient;
    private String mubiaoMessage;
    private String lujingMessage;

    private String extractedUrl;
    private String imagePath;
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;

    @Override
    public void init() throws ServletException {
        super.init();

        // MQTT Broker连接参数
        String broker = "tcp://mqtt.bemfa.com:9501";
        String imgbroker = "tcp://img.bemfa.com:8347";
        String clientId = "5c4223d5e1bb49f7ae8c701727674eda";
        String lujingTopic = "lujing";
        String mubiaoTopic = "mubiao";

        MemoryPersistence persistence = new MemoryPersistence();

        try {
            // 连接到服务器
            socket = new Socket("img.bemfa.com", 8347);

            // 获取输入输出流
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            // 发送订阅消息
            String subscribeMsg = "cmd=1&uid=5c4223d5e1bb49f7ae8c701727674eda&topic=mypicture\r\n";
            out.println(subscribeMsg);

        } catch (Exception e) {
            e.printStackTrace();
            throw new ServletException("Failed to connect to server");
        }
        // 创建定时器对象
        Timer timer = new Timer();

        // 创建定时任务2
        TimerTask heartbeatTask = new TimerTask() {
            @Override
            public void run() {
                try {
                    // 发送心跳消息
                    String heartbeatMsg = "cmd=0&msg=keep\r\n";
                    out.println(heartbeatMsg);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        timer.scheduleAtFixedRate(heartbeatTask, 0, 30 * 1000);
        try {
            mqttClient = new MqttClient(broker, clientId, persistence);

            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);

            mqttClient.connect(connOpts);

            mqttClient.subscribe(lujingTopic, new IMqttMessageListener() {
                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    lujingMessage = new String(message.getPayload(), "UTF-8");
                    System.out.println("Received lujing: " + lujingMessage);
                }
            });

            mqttClient.subscribe(mubiaoTopic, new IMqttMessageListener() {
                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    mubiaoMessage = new String(message.getPayload(), "UTF-8");
                    System.out.println("Received mubiao: " + mubiaoMessage);
                }
            });


        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String imageUrl = in.readLine();

        System.out.println(imageUrl);

        if (imageUrl.contains("cmd=2") && imageUrl.contains("msg=")) {
            int startIndex = imageUrl.indexOf("msg=") + 4;
            extractedUrl = imageUrl.substring(startIndex);
            req.setAttribute("imagePath", extractedUrl);
            System.out.println(extractedUrl);
        }
        req.setAttribute("mubiaoMessage", mubiaoMessage);
        req.setAttribute("lujingMessage", lujingMessage);
        req.getRequestDispatcher("mqtt.jsp").forward(req, resp);

        resp.getWriter().write("MQTT Subscriber Servlet");
    }

    @Override
    public void destroy() {
        super.destroy();

        try {
            mqttClient.disconnect();
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

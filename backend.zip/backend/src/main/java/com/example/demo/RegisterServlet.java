package com.example.demo;

import com.robot.Config.dbConfig;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    private Connection connection = new dbConfig().getConnection();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");

        try {
            // 连接数据库
            // 执行插入
            String sql = "INSERT INTO users (Username, Password, Email) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, username);
            statement.setString(2, password);
            statement.setString(3, email);
            statement.executeUpdate();

            // 注册成功，可以进行相应的操作，如跳转到登录页面
            response.sendRedirect("login.jsp");


            // 关闭连接
            statement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
            // 处理异常情况
            response.sendRedirect("error.jsp");
        }
    }
}

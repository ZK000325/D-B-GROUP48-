package com.example.demo.servlet.reboot;

import com.example.demo.dao.reboot.RobotDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/UpdateRobot")
public class EditRobotServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int robotId = Integer.parseInt(request.getParameter("robotId"));
        int userId = Integer.parseInt(request.getParameter("userId"));
        String name = request.getParameter("name");
        String status = request.getParameter("status");

        // 更新机器人信息
        boolean success = RobotDao.updateRobot(robotId, userId, name, status);

        if (success) {
            // 设置成功消息到请求属性
            request.setAttribute("message", "Robot updated successfully");
        } else {
            // 设置失败消息到请求属性
            request.setAttribute("message", "Failed to update Robot");
        }

        // 转发到编辑页面
        request.getRequestDispatcher("/reboot/edit.jsp").forward(request, response);
    }

}


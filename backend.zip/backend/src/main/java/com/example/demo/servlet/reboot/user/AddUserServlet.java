package com.example.demo.servlet.reboot.user;

import com.example.demo.dao.reboot.UserDao;
import com.example.demo.domian.User;
import com.example.demo.util.Message;
import com.example.demo.util.callback;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/addUser")
public class AddUserServlet extends HttpServlet {
    private  UserDao userDao =new UserDao();
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");

        // 创建新的User对象
        User newUser = new User(0, username, password, email);

        // 调用相应的DAO方法将新用户添加到数据库
        boolean success = userDao.addUser(newUser);

        if (success) {
            // 添加成功，重定向到用户列表页面
            new Message("添加成功", response, new callback() {
                @Override
                public void run() {
                    try {
                        response.sendRedirect("/reboot/user/user.jsp");
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }

                }
            });



        } else {
            // 添加失败，返回错误消息
            response.sendRedirect("/reboot/user/add.jsp?error=1");
        }
    }
}

package com.example.demo.util;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class Message {
    private String title;

    public Message(String title, HttpServletResponse resp,callback back) throws IOException {//使用工厂模式
        resp.setContentType("text/html;charset=UTF-8");
        back.run();
        PrintWriter out = resp.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<script>");
        out.println("window.onload = function() {");
        out.println("    alert('"+title+"');");


        out.println("}");
        out.println("</script>");
        out.println("</head>");
        out.println("<body>");
        out.println("<!-- 页面内容 -->");
        out.println("</body>");
        out.println("</html>");

        out.close();


    }
}

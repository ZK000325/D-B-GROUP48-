package com.example.demo.servlet.reboot.user;

import com.example.demo.dao.reboot.UserDao;
import com.example.demo.util.Message;
import com.example.demo.util.callback;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/deleteUser")
public class DeleteUserServlet extends HttpServlet {
    private UserDao userDao =new UserDao();
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int userId = Integer.parseInt(request.getParameter("userId"));

        // 调用相应的DAO方法从数据库中删除用户
        boolean success = userDao.deleteUser(userId);

        if (success) {
            // 删除成功，重定向到用户列表页面
            new Message("添加成功", response, new callback() {
                @Override
                public void run() {
                    try {
                        response.sendRedirect("/reboot/user/user.jsp");
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }

                }
            });
        } else {
            // 删除失败，返回错误消息
            response.sendRedirect("users.jsp?error=1");
        }
    }
}

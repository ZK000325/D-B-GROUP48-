package com.example.demo.servlet.reboot;


import com.example.demo.dao.reboot.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.sql.Timestamp;

@WebServlet("/AddRobotServlet")
public class AddRobotServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int userId = Integer.parseInt(request.getParameter("userId"));
        String name = request.getParameter("name");
        String status = request.getParameter("status");

//        Timestamp lastActiveTime = Timestamp.valueOf(me);

        // 调用添加机器人的方法
        boolean result = RobotDao.addRobot(userId, name, status);
        PrintWriter writer = response.getWriter();
        if (result){

            writer.write("<script>alert('添加成功')</script>");
            response.sendRedirect("reboot/index.jsp?status=0");

        }else {
            writer.write("<script>alert('添加成功')</script>");

            response.sendRedirect("reboot/index.jsp?status=1");

        }
        // 重定向到首页
    }
}

package com.example.demo.dao.reboot;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.example.demo.Robot;
import com.google.gson.Gson;
import com.robot.Config.dbConfig;
import lombok.Data;


public class RobotDao {


    public static List<Robot> getAllRobots() {
        try {
            Connection connection = new dbConfig().getConnection();
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM robots");

            List<Robot> robots = new ArrayList<>();
            while (resultSet.next()) {
                int robotId = resultSet.getInt("RobotID");
                int userId = resultSet.getInt("UserID");
                String name = resultSet.getString("Name");
                byte[] image = resultSet.getBytes("Image");
                String status = resultSet.getString("Status");
//                Timestamp lastActiveTime = resultSet.getTimestamp("LastActiveTime");

                Robot robot = new Robot(robotId, userId, name, image, status);
                robots.add(robot);
            }

//            Gson gson = new Gson();
//            String json = gson.toJson();

            resultSet.close();
            statement.close();
            connection.close();

            return robots;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Robot getRobotById(int robotId) {
        System.out.println(robotId);
        try {
            Connection connection = new dbConfig().getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM robots WHERE RobotID =?");
            statement.setInt(1, robotId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                int userId = resultSet.getInt("UserID");
                String name = resultSet.getString("Name");
                byte[] image = resultSet.getBytes("Image");
                String status = resultSet.getString("Status");
//                Timestamp lastActiveTime = resultSet.getTimestamp("LastActiveTime");
                System.out.println(userId);
                Robot robot = new Robot(robotId, userId, name, image, status);

//                Gson gson = new Gson();
//                String json = gson.toJson(robot);

                resultSet.close();
                statement.close();
                connection.close();
                System.out.println(robot);
                return robot;
            } else {
                resultSet.close();
                statement.close();
                connection.close();

                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean addRobot(int userId, String name, String status) {
        try {
            Connection connection = new dbConfig().getConnection();
            PreparedStatement statement = connection.prepareStatement("INSERT INTO robots (UserID, Name, Status) VALUES (?, ?, ?)");
            statement.setInt(1, userId);
            statement.setString(2, name);
//            statement.setBytes(3, image);
            statement.setString(3, status);
//            statement.setTimestamp(4, lastActiveTime);

            int affectedRows = statement.executeUpdate();

            statement.close();
            connection.close();

            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean updateRobot(int robotId, int userId, String name, String status) {
        try {
            Connection connection = new dbConfig().getConnection();
            PreparedStatement statement = connection.prepareStatement("UPDATE robots SET UserID = ?, Name = ?, Status = ? WHERE RobotID = ?");
            statement.setInt(1, userId);
            statement.setString(2, name);
            statement.setString(3, status);
            statement.setInt(4, robotId);

            int affectedRows = statement.executeUpdate();

            statement.close();
            connection.close();

            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public static boolean deleteRobot(int robotId) {
        try {
            Connection connection = new dbConfig().getConnection();

            PreparedStatement statement = connection.prepareStatement("DELETE FROM robots WHERE RobotID = ?");
            statement.setInt(1, robotId);

            int affectedRows = statement.executeUpdate();

            statement.close();
            connection.close();

            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
